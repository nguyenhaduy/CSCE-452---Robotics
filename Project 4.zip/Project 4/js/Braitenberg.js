var game = new Phaser.Game(800, 800, Phaser.CANVAS, null, {
  preload: preload, create: create, update: update});

var car
var sensor1
var sensor2
var w1
var w2

function preload() {
    game.scale.scaleMode = Phaser.ScaleManager.SHOW_ALL;
    game.scale.pageAlignHorizontally = true;
    game.scale.pageAlignVertically = true;
    game.stage.backgroundColor = '#555';
    game.load.image('car', 'img/Audi.png');
    game.load.image('light', 'img/Light.png');
    game.load.image('sensor', 'img/sensor.png');
}

function create() {
	game.world.setBounds(0,0,800,800);
	game.physics.startSystem(Phaser.Physics.ARCADE);
	
	car = game.add.sprite(300, 300, 'car');
	car.scale.setTo(.25, .25);
	
	game.physics.arcade.enable(car);
	car.body.collideWorldBounds = true;
	

	sensor1 = game.add.sprite(0, 0, 'sensor');
	sensor1.scale.setTo(.25, .25);
	sensor1.anchor.setTo(-1.25, -.25);

	sensor2 = game.add.sprite(0, 0, 'sensor');
	sensor2.scale.setTo(.25, .25);
	sensor2.anchor.setTo(-2.75, -.25);

	car.addChild(sensor1);
	car.addChild(sensor2);
	
	// car.body.velocity.x = 20;
	// car.body.velocity.y = -50;
}

function update() {
	// console.log("sensor1 = " + sensor1.world);
	// console.log("car = " + car.position);
}

function braitenberg() {  

}
